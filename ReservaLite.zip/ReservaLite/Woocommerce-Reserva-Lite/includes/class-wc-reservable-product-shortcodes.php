<?php
// Archivo: includes/class-wc-reservable-product-shortcodes.php

if (!class_exists('WC_Reservable_Product_Shortcodes')) {
    class WC_Reservable_Product_Shortcodes {

        public function __construct() {
            // Registrar el shortcode y la acción AJAX
            add_shortcode('calendario_reservas', [$this, 'mostrar_calendario_reservas_shortcode']);
            add_action('wp_ajax_get_reserva_pedidos', [$this, 'obtener_pedidos_reserva']);
            add_action('wp_ajax_nopriv_get_reserva_pedidos', [$this, 'obtener_pedidos_reserva']);
        }

        // Función que muestra el calendario si la opción está activada
        public function mostrar_calendario_reservas_shortcode() {
            // Verificar si la opción de mostrar el calendario está activada
            $show_calendar = get_option('wc_reservable_show_calendar', 'no');
            
            if ($show_calendar === 'yes') {
                // Encolar scripts y estilos de FullCalendar
                wp_enqueue_script('fullcalendar-core', 'https://cdn.jsdelivr.net/npm/fullcalendar@5.11.0/main.min.js', array(), null, true);
                wp_enqueue_style('fullcalendar-core-css', 'https://cdn.jsdelivr.net/npm/fullcalendar@5.11.0/main.min.css');
                wp_enqueue_script('fullcalendar-locale', 'https://cdn.jsdelivr.net/npm/fullcalendar@5.11.0/locales-all.min.js', array(), null, true);
                
                // Incluir el template HTML del calendario
                ob_start();
                include plugin_dir_path(__FILE__) . '../templates/calendar.php';
                return ob_get_clean();
            } else {
                return ''; // Si está desactivado, no mostrar nada
            }
        }

        // Función para obtener los pedidos de reserva con la fecha y hora de reserva
        public function obtener_pedidos_reserva() {
            global $wpdb;
            
            // Consulta para obtener los pedidos de reserva
            $results = $wpdb->get_results("
                SELECT 
                    p.ID AS order_id, 
                    p.post_status AS order_status,
                    oi.order_item_name AS product_name,
                    oim_date.meta_value AS booking_date,
                    oim_time.meta_value AS booking_time
                FROM 
                    {$wpdb->prefix}posts p
                LEFT JOIN {$wpdb->prefix}woocommerce_order_items oi ON p.ID = oi.order_id
                LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim_date ON oi.order_item_id = oim_date.order_item_id 
                    AND oim_date.meta_key = 'Fecha de reserva'
                LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim_time ON oi.order_item_id = oim_time.order_item_id 
                    AND oim_time.meta_key = 'Hora de reserva'
                WHERE 
                    p.post_type = 'shop_order'
                    AND p.post_status IN ('wc-processing', 'wc-completed', 'wc-on-hold')
                ORDER BY p.post_date DESC
            ");

            // Convertir los pedidos a eventos para el calendario
            $events = [];
            foreach ($results as $pedido) {
                $color = ($pedido->order_status == 'wc-on-hold') ? '#a67d0d' : (($pedido->order_status == 'wc-completed') ? 'green' : '');
                $events[] = [
                    'title' => 'Reserva: ' . $pedido->product_name,
                    'start' => date('Y-m-d\TH:i:s', strtotime($pedido->booking_date . ' ' . $pedido->booking_time)),
                    'url' => admin_url('post.php?post=' . $pedido->order_id . '&action=edit'),
                    'color' => $color
                ];
            }

            // Devolver los eventos en JSON
            echo json_encode($events);
            wp_die();
        }
    }
}

// Inicializar la clase de shortcodes solo si no existe otra instancia
if (class_exists('WC_Reservable_Product_Shortcodes')) {
    new WC_Reservable_Product_Shortcodes();
}
