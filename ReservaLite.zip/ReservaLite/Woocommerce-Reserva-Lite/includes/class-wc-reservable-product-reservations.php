<?php

class WC_Reservable_Product_Reservations {

    public function __construct() {
        add_action('woocommerce_before_add_to_cart_button', array($this, 'mostrar_campos_fecha_hora'));
        add_filter('woocommerce_add_to_cart_validation', array($this, 'validar_reserva'), 10, 3);
    }

    // Mostrar los campos personalizados de fecha y/o hora en productos reservables según el modo de reserva
    public function mostrar_campos_fecha_hora() {
        $reservation_mode = get_option('wc_reservable_reservation_mode', 'date_time');
        
        // Incluir template personalizado que usará la opción de reserva
        include WOO_RESERVABLE_PLUGIN_DIR . 'templates/date-time-fields.php';
    }

    // Validar si se permite la reserva en la fecha/hora seleccionada
    public function validar_reserva($passed, $product_id, $quantity) {
        $allow_multiple_reservations = get_option('wc_reservable_allow_multiple_reservations', 'no');
        $reservation_mode = get_option('wc_reservable_reservation_mode', 'date_time');

        if (isset($_POST['reservation_date']) && ($reservation_mode === 'date_time' || $reservation_mode === 'date')) {
            $reservation_date = sanitize_text_field($_POST['reservation_date']);
            $reservation_time = $reservation_mode === 'time' ? '' : sanitize_text_field($_POST['reservation_time']);

            // Verificar si no se permite múltiples reservas y ya existe una reserva en esta fecha/hora
            if ($allow_multiple_reservations === 'no' && $this->existe_reserva($product_id, $reservation_date, $reservation_time)) {
                wc_add_notice(__('La fecha y hora seleccionada ya están reservadas. Por favor, selecciona otra.', 'woocommerce-reservable-product'), 'error');
                $passed = false;
            }
        }

        return $passed;
    }

    // Comprobar si ya existe una reserva en la fecha/hora seleccionada
    private function existe_reserva($product_id, $reservation_date, $reservation_time = '') {
        global $wpdb;

        $query = "
            SELECT COUNT(*)
            FROM {$wpdb->prefix}woocommerce_order_itemmeta oim
            INNER JOIN {$wpdb->prefix}woocommerce_order_items oi ON oim.order_item_id = oi.order_item_id
            INNER JOIN {$wpdb->prefix}posts p ON oi.order_id = p.ID
            WHERE oim.meta_key = '_product_id'
            AND oim.meta_value = %d
            AND oi.meta_key = 'Fecha de reserva'
            AND oi.meta_value = %s
            AND p.post_status NOT IN ('wc-cancelled', 'trash')
        ";

        $params = array($product_id, $reservation_date);

        if ($reservation_time) {
            $query .= " AND oi.meta_key = 'Hora de reserva' AND oi.meta_value = %s";
            $params[] = $reservation_time;
        }

        $reservas_count = $wpdb->get_var($wpdb->prepare($query, ...$params));
        return $reservas_count > 0;
    }
}

new WC_Reservable_Product_Reservations();
