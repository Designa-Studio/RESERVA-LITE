<?php

class WC_Reservable_Product_Settings {

    public function __construct() {
        add_action('admin_menu', array($this, 'agregar_menu_reservas'));
    }

    // Función para agregar el menú y submenús en el panel de administración
    public function agregar_menu_reservas() {
        // Menú principal de Reservas
        add_menu_page(
            __('Reservas', 'woocommerce-reservable-product'),  // Título de la página
            __('Reservas', 'woocommerce-reservable-product'),  // Título del menú
            'manage_woocommerce',  // Capacidad necesaria
            'reservas',  // Slug
            array($this, 'mostrar_pagina_reservas'),  // Función que muestra el contenido
            'dashicons-calendar',  // Icono
            56  // Posición en el menú
        );

        // Submenú de Shortcodes
        add_submenu_page(
            'reservas',  // Slug del menú padre
            __('Shortcodes', 'woocommerce-reservable-product'),  // Título de la página
            __('Shortcodes', 'woocommerce-reservable-product'),  // Título del submenú
            'manage_woocommerce',  // Capacidad necesaria
            'shortcodes',  // Slug del submenú
            array($this, 'mostrar_pagina_shortcodes')  // Función del contenido
        );

        // Submenú de Configuraciones
        add_submenu_page(
            'reservas',  // Slug del menú padre
            __('Configuraciones', 'woocommerce-reservable-product'),  // Título de la página
            __('Configuraciones', 'woocommerce-reservable-product'),  // Título del submenú
            'manage_woocommerce',  // Capacidad necesaria
            'reservas-configuraciones',  // Slug del submenú
            array($this, 'mostrar_pagina_configuraciones')  // Función del contenido
        );
    }

    // Función para mostrar la página principal de Reservas
    public function mostrar_pagina_reservas() {
        include WOO_RESERVABLE_PLUGIN_DIR . 'templates/admin-reservas-page.php';
    }

    // Función para mostrar la página de Shortcodes
    public function mostrar_pagina_shortcodes() {
        include WOO_RESERVABLE_PLUGIN_DIR . 'templates/admin-shortcodes-page.php';
    }

    // Función para mostrar la página de Configuraciones
    public function mostrar_pagina_configuraciones() {
        include WOO_RESERVABLE_PLUGIN_DIR . 'templates/admin-configuraciones-page.php';
    }
}

new WC_Reservable_Product_Settings();
