<?php
/**
 * Plugin Name: Reserva Lite
 * Description: Añade un tipo de producto reservable a WooCommerce con opciones avanzadas de configuración de reservas.
 * Version: 2.5
 * Author: Designa Studios
 * Text Domain: reserva-lite
 * */

if (!defined('ABSPATH')) {
    exit; // Salir si se accede directamente
}

// Define la ruta del plugin
define('WOO_RESERVABLE_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WOO_RESERVABLE_PLUGIN_URL', plugin_dir_url(__FILE__));

// Cargar archivos necesarios
function wc_reservable_product_includes() {
    // Incluye archivos de clases
    require_once WOO_RESERVABLE_PLUGIN_DIR . 'includes/class-wc-reservable-product-settings.php';
    require_once WOO_RESERVABLE_PLUGIN_DIR . 'includes/class-wc-reservable-product-shortcodes.php';
    require_once WOO_RESERVABLE_PLUGIN_DIR . 'includes/class-wc-reservable-product-reservations.php';
}

// Ejecuta la función de carga de archivos
wc_reservable_product_includes();

// Inicializar clases del plugin
function wc_reservable_product_init() {
    new WC_Reservable_Product_Settings();       // Configuración del plugin y opciones administrativas
    new WC_Reservable_Product_Shortcodes();     // Manejo de shortcodes
    new WC_Reservable_Product_Reservations();   // Funcionalidades de reservas y validación de reservas
}

// Hook para inicializar el plugin después de cargar WooCommerce
add_action('plugins_loaded', 'wc_reservable_product_init');

// Registrar scripts y estilos
function wc_reservable_enqueue_scripts() {
    // Script y estilos personalizados para el frontend
    wp_enqueue_style('flatpickr-css', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css');
    wp_enqueue_script('flatpickr-js', 'https://cdn.jsdelivr.net/npm/flatpickr', array('jquery'), null, true);

    // FullCalendar para el calendario de reservas
    wp_enqueue_script('fullcalendar-core', 'https://cdn.jsdelivr.net/npm/fullcalendar@5.11.0/main.min.js', array(), null, true);
    wp_enqueue_style('fullcalendar-core-css', 'https://cdn.jsdelivr.net/npm/fullcalendar@5.11.0/main.min.css');
    wp_enqueue_script('fullcalendar-locale', 'https://cdn.jsdelivr.net/npm/fullcalendar@5.11.0/locales-all.min.js', array(), null, true);

    // JavaScript personalizado para el plugin
    wp_enqueue_script('wc-reservable-scripts', WOO_RESERVABLE_PLUGIN_URL . 'assets/js/wc-reservable-scripts.js', array('jquery'), null, true);
}

// Hook para cargar scripts y estilos en el frontend
add_action('wp_enqueue_scripts', 'wc_reservable_enqueue_scripts');
