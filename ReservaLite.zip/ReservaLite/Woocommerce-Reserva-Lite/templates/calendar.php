<div id="calendar"></div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');
        var calendar = new FullCalendar.Calendar(calendarEl, {
            locale: 'es',
            initialView: 'dayGridMonth',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,listWeek'
            },
            events: '<?php echo admin_url('admin-ajax.php?action=get_reserva_pedidos'); ?>',
            eventClick: function(info) {
                if (info.event.url) {
                    window.open(info.event.url, "_self");
                    return false;
                }
            },
            slotMinTime: '08:00:00',
            slotMaxTime: '20:00:00'
        });
        calendar.render();
    });
</script>
