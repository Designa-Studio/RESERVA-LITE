<div class="wrap">
    <h1><?php _e('Estadísticas de Reservas', 'woocommerce-reservable-product'); ?></h1>
    <p><?php _e('Aquí puedes ver un resumen de las reservas registradas en el sistema.', 'woocommerce-reservable-product'); ?></p>

    <?php
    global $wpdb;
    $total_registradas = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}posts WHERE post_type = 'shop_order' AND post_status != 'trash'");
    $total_aprobadas = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}posts WHERE post_type = 'shop_order' AND post_status = 'wc-completed' AND post_status != 'trash'");
    $total_canceladas = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}posts WHERE post_type = 'shop_order' AND post_status = 'wc-cancelled' AND post_status != 'trash'");
    $total_en_espera = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}posts WHERE post_type = 'shop_order' AND post_status = 'wc-on-hold' AND post_status != 'trash'");
    $total_procesando = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}posts WHERE post_type = 'shop_order' AND post_status = 'wc-processing' AND post_status != 'trash'");
    ?>

    <table class="widefat fixed" cellspacing="0">
        <thead>
            <tr>
                <th><?php _e('Estado', 'woocommerce-reservable-product'); ?></th>
                <th><?php _e('Cantidad', 'woocommerce-reservable-product'); ?></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php _e('Total Registradas', 'woocommerce-reservable-product'); ?></td>
                <td><?php echo esc_html($total_registradas); ?></td>
            </tr>
            <tr>
                <td><?php _e('Total Aprobadas', 'woocommerce-reservable-product'); ?></td>
                <td><?php echo esc_html($total_aprobadas); ?></td>
            </tr>
            <tr>
                <td><?php _e('Total Canceladas', 'woocommerce-reservable-product'); ?></td>
                <td><?php echo esc_html($total_canceladas); ?></td>
            </tr>
            <tr>
                <td><?php _e('Total en Espera', 'woocommerce-reservable-product'); ?></td>
                <td><?php echo esc_html($total_en_espera); ?></td>
            </tr>
            <tr>
                <td><?php _e('Total Procesando', 'woocommerce-reservable-product'); ?></td>
                <td><?php echo esc_html($total_procesando); ?></td>
            </tr>
        </tbody>
    </table>
</div>
