<?php
$reservation_mode = get_option('wc_reservable_reservation_mode', 'date_time');
?>

<div class="wc-reservable-fields">
    <?php if ($reservation_mode === 'date' || $reservation_mode === 'date_time') : ?>
        <p>
            <label for="reservation_date"><?php _e('Fecha de reserva', 'woocommerce-reservable-product'); ?></label>
            <input type="text" id="reservation_date" name="reservation_date" required>
        </p>
    <?php endif; ?>

    <?php if ($reservation_mode === 'time' || $reservation_mode === 'date_time') : ?>
        <p>
            <label for="reservation_time"><?php _e('Hora de reserva', 'woocommerce-reservable-product'); ?></label>
            <select id="reservation_time" name="reservation_time" <?php echo $reservation_mode === 'time' ? 'required' : ''; ?>>
                <option value=""><?php _e('Selecciona una hora', 'woocommerce-reservable-product'); ?></option>
                <?php
                // Generar todas las horas del d��a (00:00 - 23:30) en intervalos de 30 minutos
                for ($i = 0; $i < 24; $i++) {
                    for ($minutes = 0; $minutes < 60; $minutes += 30) {
                        $hour = sprintf('%02d:%02d', $i, $minutes);  // Formato 00:00, 00:30, 01:00, etc.
                        echo "<option value='$hour'>$hour</option>";
                    }
                }
                ?>
            </select>
        </p>
    <?php endif; ?>
</div>

<script type="text/javascript">
    jQuery(document).ready(function($) {
        $('#reservation_date').flatpickr({
            dateFormat: 'Y-m-d',
        });
    });
</script>
