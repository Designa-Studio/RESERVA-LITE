<div class="wrap">
    <h1><?php _e('Shortcodes', 'woocommerce-reservable-product'); ?></h1>

    <?php
    if (isset($_POST['save_shortcode_option'])) {
        $show_calendar = isset($_POST['show_calendar']) ? 'yes' : 'no';
        update_option('wc_reservable_show_calendar', $show_calendar);
        echo '<div class="updated"><p>' . __('Configuración guardada.', 'woocommerce-reservable-product') . '</p></div>';
    }

    $show_calendar = get_option('wc_reservable_show_calendar', 'no');
    ?>

    <form method="post">
        <p><?php _e('Aquí puedes activar o desactivar el shortcode del calendario de reservas.', 'woocommerce-reservable-product'); ?></p>
        <label>
            <input type="checkbox" name="show_calendar" <?php checked($show_calendar, 'yes'); ?> />
            <?php _e('Activar el shortcode [calendario_reservas]', 'woocommerce-reservable-product'); ?>
        </label>
        <br><br>
        <input type="submit" name="save_shortcode_option" class="button button-primary" value="<?php _e('Guardar Cambios', 'woocommerce-reservable-product'); ?>">
    </form>

    <h2><?php _e('Uso del Shortcode', 'woocommerce-reservable-product'); ?></h2>
    <p><?php _e('Utiliza el siguiente shortcode para mostrar el calendario en cualquier página o entrada:', 'woocommerce-reservable-product'); ?></p>
    <code>[calendario_reservas]</code>
</div>
