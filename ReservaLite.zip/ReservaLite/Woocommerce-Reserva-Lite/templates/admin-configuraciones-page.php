<div class="wrap">
    <h1><?php _e('Configuraciones', 'woocommerce-reservable-product'); ?></h1>
    <form method="post">
        <?php
        // Guarda las opciones si el formulario se ha enviado
        if (isset($_POST['save_settings'])) {
            $show_calendar_button = isset($_POST['show_calendar_button']) ? 'yes' : 'no';
            $allow_multiple_reservations = isset($_POST['allow_multiple_reservations']) ? 'yes' : 'no';
            $reservation_mode = isset($_POST['reservation_mode']) ? sanitize_text_field($_POST['reservation_mode']) : 'date_time';

            update_option('wc_reservable_show_calendar_button', $show_calendar_button);
            update_option('wc_reservable_allow_multiple_reservations', $allow_multiple_reservations);
            update_option('wc_reservable_reservation_mode', $reservation_mode);

            echo '<div class="updated"><p>' . __('Configuración guardada.', 'woocommerce-reservable-product') . '</p></div>';
        }

        // Obtener los valores actuales de las opciones
        $show_calendar_button = get_option('wc_reservable_show_calendar_button', 'no');
        $allow_multiple_reservations = get_option('wc_reservable_allow_multiple_reservations', 'no');
        $reservation_mode = get_option('wc_reservable_reservation_mode', 'date_time');
        ?>

        <h2><?php _e('Opciones de Menú de Mi Cuenta', 'woocommerce-reservable-product'); ?></h2>
        <label>
            <input type="checkbox" name="show_calendar_button" <?php checked($show_calendar_button, 'yes'); ?> />
            <?php _e('Mostrar botón "Calendario" en el menú de Mi Cuenta (solo para administradores)', 'woocommerce-reservable-product'); ?>
        </label>

        <h2><?php _e('Opciones de Reservas', 'woocommerce-reservable-product'); ?></h2>
        <label>
            <input type="checkbox" name="allow_multiple_reservations" <?php checked($allow_multiple_reservations, 'yes'); ?> />
            <?php _e('Permitir múltiples reservas en la misma hora', 'woocommerce-reservable-product'); ?>
        </label>
        <br><br>

        <label><?php _e('Modo de Reserva:', 'woocommerce-reservable-product'); ?></label>
        <select name="reservation_mode">
            <option value="date" <?php selected($reservation_mode, 'date'); ?>><?php _e('Solo Fecha', 'woocommerce-reservable-product'); ?></option>
            <option value="time" <?php selected($reservation_mode, 'time'); ?>><?php _e('Solo Hora', 'woocommerce-reservable-product'); ?></option>
            <option value="date_time" <?php selected($reservation_mode, 'date_time'); ?>><?php _e('Fecha y Hora', 'woocommerce-reservable-product'); ?></option>
        </select>

        <br><br>
        <input type="submit" name="save_settings" class="button button-primary" value="<?php _e('Guardar Cambios', 'woocommerce-reservable-product'); ?>">
    </form>
</div>
